'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, ShoppingCart, Filter } from 'lucide-react'
import Header from '@/components/header'
import ProductCard from '@/components/product-card'
import { Button } from '@/components/ui/button'

interface Product {
  id: string
  name: string
  category: string
  price: number
  originalPrice?: number
  image: string
  rating: number
  reviews: number
  badge?: string
}

const products: Product[] = [
  {
    id: '1',
    name: 'Whey Protein Isolado',
    category: 'Suplementos',
    price: 149.90,
    originalPrice: 199.90,
    image: '/whey-protein-isolado.jpg',
    rating: 5,
    reviews: 324,
    badge: 'Bestseller'
  },
  {
    id: '2',
    name: 'Creatina Monohidratada',
    category: 'Suplementos',
    price: 89.90,
    originalPrice: 129.90,
    image: '/creatina-monohidratada.jpg',
    rating: 4.5,
    reviews: 156,
    badge: 'Em Alta'
  },
  {
    id: '3',
    name: 'BCAA Aminoácidos',
    category: 'Suplementos',
    price: 74.90,
    image: '/bcaa-aminoacidos.jpg',
    rating: 4,
    reviews: 89,
  },
  {
    id: '4',
    name: 'Pré-Treino Energy Boost',
    category: 'Suplementos',
    price: 119.90,
    originalPrice: 159.90,
    image: '/pre-treino.jpg',
    rating: 4.5,
    reviews: 203,
  },
  {
    id: '5',
    name: 'Multivitamínico Diário',
    category: 'Suplementos',
    price: 64.90,
    image: '/multivitaminico.jpg',
    rating: 4,
    reviews: 142,
  },
  {
    id: '6',
    name: 'Ômega 3 Premium',
    category: 'Suplementos',
    price: 99.90,
    originalPrice: 139.90,
    image: '/omega-3-premium.jpg',
    rating: 5,
    reviews: 267,
    badge: 'Bestseller'
  },
  {
    id: '7',
    name: 'Camiseta Dry Fit Premium',
    category: 'Roupas',
    price: 89.90,
    originalPrice: 129.90,
    image: '/camiseta-dry-fit.jpg',
    rating: 4.5,
    reviews: 178,
  },
  {
    id: '8',
    name: 'Shorts Treino Masculino',
    category: 'Roupas',
    price: 99.90,
    originalPrice: 149.90,
    image: '/shorts-treino.jpg',
    rating: 4,
    reviews: 95,
  },
  {
    id: '9',
    name: 'Legging Compressão Feminina',
    category: 'Roupas',
    price: 129.90,
    originalPrice: 179.90,
    image: '/legging-compressao.jpg',
    rating: 5,
    reviews: 312,
    badge: 'Bestseller'
  },
  {
    id: '10',
    name: 'Jaqueta Impermeável',
    category: 'Roupas',
    price: 199.90,
    image: '/jaqueta-impermeavel.jpg',
    rating: 4.5,
    reviews: 126,
  },
  {
    id: '11',
    name: 'Mochila Treino 40L',
    category: 'Acessórios',
    price: 149.90,
    originalPrice: 199.90,
    image: '/mochila-treino.jpg',
    rating: 4,
    reviews: 203,
  },
  {
    id: '12',
    name: 'Garrafa Térmica 1L',
    category: 'Acessórios',
    price: 69.90,
    image: '/garrafa-termica.jpg',
    rating: 4.5,
    reviews: 287,
  },
  {
    id: '13',
    name: 'Fone Bluetooth Esportivo',
    category: 'Acessórios',
    price: 199.90,
    originalPrice: 249.90,
    image: '/fone-bluetooth-esportivo.jpg',
    rating: 5,
    reviews: 445,
    badge: 'Bestseller'
  },
  {
    id: '14',
    name: 'Relógio Smartwatch Fitness',
    category: 'Eletrônicos',
    price: 449.90,
    originalPrice: 599.90,
    image: '/smartwatch-fitness.png',
    rating: 4.5,
    reviews: 534,
  },
  {
    id: '15',
    name: 'Fita de Resistência Set',
    category: 'Equipamentos',
    price: 79.90,
    image: '/fita-resistencia.jpg',
    rating: 4,
    reviews: 156,
  },
  {
    id: '16',
    name: 'Tapete Yoga Premium',
    category: 'Equipamentos',
    price: 129.90,
    originalPrice: 179.90,
    image: '/tapete-yoga.jpg',
    rating: 4.5,
    reviews: 198,
  },
  {
    id: '17',
    name: 'Halteres Ajustáveis 20kg',
    category: 'Equipamentos',
    price: 349.90,
    originalPrice: 449.90,
    image: '/placeholder.svg?height=200&width=200',
    rating: 5,
    reviews: 267,
    badge: 'Bestseller'
  },
  {
    id: '18',
    name: 'Colchonete Espuma Alta Densidade',
    category: 'Equipamentos',
    price: 89.90,
    image: '/placeholder.svg?height=200&width=200',
    rating: 4,
    reviews: 134,
  },
]

const categories = ['Todos', 'Suplementos', 'Roupas', 'Acessórios', 'Eletrônicos', 'Equipamentos']

export default function StoreList() {
  const [selectedCategory, setSelectedCategory] = useState('Todos')
  const [cartItems, setCartItems] = useState<Product[]>([])
  const [showCart, setShowCart] = useState(false)

  const filteredProducts = selectedCategory === 'Todos' 
    ? products 
    : products.filter(p => p.category === selectedCategory)

  const handleAddToCart = (product: Product) => {
    setCartItems([...cartItems, product])
  }

  const handleRemoveFromCart = (index: number) => {
    setCartItems(cartItems.filter((_, i) => i !== index))
  }

  const cartTotal = cartItems.reduce((sum, item) => sum + item.price, 0)

  return (
    <>
      <Header />
      <main className="min-h-screen bg-gradient-to-b from-background via-card to-background">
        <div className="container mx-auto px-4 py-12">
          <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-8">
            <ArrowLeft className="w-5 h-5" />
            Voltar para Home
          </Link>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
            <div>
              <h1 className="text-4xl font-bold mb-2">Loja FitFlow</h1>
              <p className="text-muted-foreground">Tudo o que você precisa para sua jornada fitness</p>
            </div>
            <button
              onClick={() => setShowCart(!showCart)}
              className="relative bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              Carrinho
              {cartItems.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </button>
          </div>

          {/* Carrinho Lateral */}
          {showCart && (
            <div className="fixed right-0 top-0 h-full w-full md:w-96 bg-card shadow-lg rounded-l-xl z-50 overflow-y-auto flex flex-col">
              <div className="p-6 border-b border-border sticky top-0 bg-card">
                <h2 className="text-2xl font-bold">Carrinho</h2>
              </div>

              <div className="flex-1 overflow-y-auto p-6">
                {cartItems.length === 0 ? (
                  <p className="text-muted-foreground text-center py-12">Seu carrinho está vazio</p>
                ) : (
                  <div className="space-y-4">
                    {cartItems.map((item, index) => (
                      <div key={index} className="bg-background p-4 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-semibold">{item.name}</p>
                            <p className="text-sm text-muted-foreground">{item.category}</p>
                          </div>
                          <button
                            onClick={() => handleRemoveFromCart(index)}
                            className="text-red-500 hover:text-red-600 text-sm font-semibold"
                          >
                            Remover
                          </button>
                        </div>
                        <p className="text-primary font-bold">R$ {item.price.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {cartItems.length > 0 && (
                <div className="border-t border-border p-6 bg-card">
                  <div className="space-y-3 mb-4">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-primary">R$ {cartTotal.toFixed(2)}</span>
                    </div>
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                    Finalizar Compra
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Filtros de Categoria */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-4">
              <Filter className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Categorias</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedCategory === category
                      ? 'bg-primary text-white'
                      : 'bg-card hover:bg-card/80 text-foreground'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Produtos */}
          <div>
            <h2 className="text-2xl font-bold mb-8">{selectedCategory === 'Todos' ? 'Todos os Produtos' : selectedCategory}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
