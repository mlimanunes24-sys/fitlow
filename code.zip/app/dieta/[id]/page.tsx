'use client'

import { useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Apple, Flame } from 'lucide-react'
import BackButton from '@/components/back-button'

const dietsData: any = {
  hipertrofia: {
    name: 'Hipertrofia',
    color: 'from-red-600 to-pink-600',
    description: 'Foco em ganho de massa muscular com superávit calórico',
    calorias: '3000-3500 kcal',
    macros: { proteina: '2.2g/kg', carboidrato: '4-5g/kg', gordura: '0.8-1g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Ovos, aveia, banana, mel', proteina: '30g', carbos: '60g', gordura: '15g' },
      { nome: 'Lanche 1', hora: '10:00', alimentos: 'Whey protein, arroz integral', proteina: '30g', carbos: '50g', gordura: '5g' },
      { nome: 'Almoço', hora: '13:00', alimentos: 'Frango, arroz, batata doce, brócolis', proteina: '50g', carbos: '80g', gordura: '10g' },
      { nome: 'Lanche 2', hora: '16:00', alimentos: 'Frutas, oleaginosas, iogurte grego', proteina: '20g', carbos: '40g', gordura: '12g' },
      { nome: 'Jantar', hora: '19:00', alimentos: 'Salmão, macarrão integral, abacate', proteina: '45g', carbos: '70g', gordura: '18g' },
    ]
  },
  definicao: {
    name: 'Definição',
    color: 'from-blue-600 to-cyan-600',
    description: 'Redução de gordura corporal mantendo a massa muscular',
    calorias: '1800-2200 kcal',
    macros: { proteina: '2.5g/kg', carboidrato: '2-3g/kg', gordura: '0.5-0.8g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Clara de ovo, aveia, maçã', proteina: '25g', carbos: '40g', gordura: '5g' },
      { nome: 'Lanche 1', hora: '10:00', alimentos: 'Whey protein light, brócolis', proteina: '30g', carbos: '25g', gordura: '2g' },
      { nome: 'Almoço', hora: '13:00', alimentos: 'Frango desfiado, arroz integral, salada', proteina: '45g', carbos: '50g', gordura: '8g' },
      { nome: 'Lanche 2', hora: '16:00', alimentos: 'Iogurte grego, mel, frutas vermelhas', proteina: '20g', carbos: '30g', gordura: '3g' },
    ]
  },
  manutencao: {
    name: 'Manutenção',
    color: 'from-green-600 to-emerald-600',
    description: 'Manter o peso e a composição corporal atual',
    calorias: '2300-2700 kcal',
    macros: { proteina: '1.8g/kg', carboidrato: '3-4g/kg', gordura: '0.7-0.9g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Ovos, pão integral, queijo, suco', proteina: '25g', carbos: '50g', gordura: '10g' },
      { nome: 'Lanche 1', hora: '10:00', alimentos: 'Fruta, castanhas, café', proteina: '10g', carbos: '35g', gordura: '8g' },
      { nome: 'Almoço', hora: '13:00', alimentos: 'Frango, batata doce, legumes, azeite', proteina: '40g', carbos: '65g', gordura: '12g' },
      { nome: 'Lanche 2', hora: '16:00', alimentos: 'Iogurte natural, granola, mel', proteina: '15g', carbos: '40g', gordura: '6g' },
    ]
  },
  bulking: {
    name: 'Bulking',
    color: 'from-orange-600 to-yellow-600',
    description: 'Ganho máximo de massa com maior superávit calórico',
    calorias: '3500-4000 kcal',
    macros: { proteina: '2g/kg', carboidrato: '5-6g/kg', gordura: '1-1.2g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Ovos, aveia, granola, leite integral, mel', proteina: '35g', carbos: '80g', gordura: '20g' },
      { nome: 'Lanche 1', hora: '9:30', alimentos: 'Frutas, castanhas, whey protein, aveia', proteina: '30g', carbos: '70g', gordura: '15g' },
      { nome: 'Almoço', hora: '12:30', alimentos: 'Carne vermelha, arroz, feijão, óleo', proteina: '55g', carbos: '100g', gordura: '20g' },
      { nome: 'Lanche 2', hora: '15:00', alimentos: 'Whey protein, frutas, amendoim', proteina: '35g', carbos: '60g', gordura: '15g' },
      { nome: 'Pré-treino', hora: '17:00', alimentos: 'Banana, aveia, mel', proteina: '10g', carbos: '50g', gordura: '5g' },
      { nome: 'Jantar', hora: '19:30', alimentos: 'Salmão, macarrão integral, batata doce', proteina: '45g', carbos: '90g', gordura: '18g' },
    ]
  },
  'cutting-extremo': {
    name: 'Cutting Extremo',
    color: 'from-slate-600 to-slate-700',
    description: 'Máxima redução de gordura em curto período',
    calorias: '1500-1800 kcal',
    macros: { proteina: '3g/kg', carboidrato: '1.5-2g/kg', gordura: '0.4-0.6g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Clara de ovo, aveia sem óleo, chá verde', proteina: '20g', carbos: '30g', gordura: '2g' },
      { nome: 'Almoço', hora: '12:00', alimentos: 'Peito de frango magro, brócolis, cenoura', proteina: '50g', carbos: '35g', gordura: '4g' },
      { nome: 'Lanche', hora: '15:00', alimentos: 'Whey isolada, maçã verde', proteina: '30g', carbos: '20g', gordura: '1g' },
    ]
  },
  emagrecimento: {
    name: 'Emagrecimento',
    color: 'from-cyan-600 to-blue-700',
    description: 'Perda gradual de peso com nutrientes adequados',
    calorias: '1600-2000 kcal',
    macros: { proteina: '2.2g/kg', carboidrato: '2-3g/kg', gordura: '0.5-0.7g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Iogurte grego, granola light, frutas', proteina: '20g', carbos: '45g', gordura: '5g' },
      { nome: 'Lanche 1', hora: '10:00', alimentos: 'Maçã, amendoim sem sal', proteina: '8g', carbos: '35g', gordura: '8g' },
      { nome: 'Almoço', hora: '13:00', alimentos: 'Frango desfiado, arroz integral, salada', proteina: '40g', carbos: '55g', gordura: '7g' },
      { nome: 'Lanche 2', hora: '16:00', alimentos: 'Proteína vegetal, cenoura', proteina: '15g', carbos: '25g', gordura: '2g' },
    ]
  },
  recomposicao: {
    name: 'Recomposição',
    color: 'from-violet-600 to-purple-700',
    description: 'Ganho de massa e perda de gordura simultânea',
    calorias: '2200-2600 kcal',
    macros: { proteina: '2.2g/kg', carboidrato: '3-3.5g/kg', gordura: '0.7-0.9g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '7:00', alimentos: 'Ovos, pão integral, abacate', proteina: '25g', carbos: '45g', gordura: '10g' },
      { nome: 'Lanche 1', hora: '10:00', alimentos: 'Whey protein, banana, amêndoas', proteina: '25g', carbos: '40g', gordura: '8g' },
      { nome: 'Almoço', hora: '13:00', alimentos: 'Peixe branco, batata doce, verduras', proteina: '45g', carbos: '70g', gordura: '8g' },
      { nome: 'Lanche 2', hora: '16:00', alimentos: 'Iogurte grego, frutas vermelhas', proteina: '18g', carbos: '35g', gordura: '4g' },
      { nome: 'Jantar', hora: '19:00', alimentos: 'Frango, arroz integral, legumes', proteina: '40g', carbos: '60g', gordura: '8g' },
    ]
  },
  'maintenance-alto-atleta': {
    name: 'Manutenção Alto Atleta',
    color: 'from-amber-600 to-orange-700',
    description: 'Dieta para atletas com alta demanda energética',
    calorias: '3000-3500 kcal',
    macros: { proteina: '2g/kg', carboidrato: '4.5-5.5g/kg', gordura: '0.8-1g/kg' },
    refeicoes: [
      { nome: 'Café da Manhã', hora: '6:30', alimentos: 'Ovos, aveia, mel, banana', proteina: '30g', carbos: '70g', gordura: '12g' },
      { nome: 'Lanche 1', hora: '9:00', alimentos: 'Frutas, castanhas, whey protein', proteina: '25g', carbos: '60g', gordura: '10g' },
      { nome: 'Almoço', hora: '12:00', alimentos: 'Carne vermelha, arroz, feijão, salada', proteina: '50g', carbos: '90g', gordura: '12g' },
      { nome: 'Pré-treino', hora: '15:00', alimentos: 'Banana, mel, aveia', proteina: '10g', carbos: '60g', gordura: '2g' },
      { nome: 'Pós-treino', hora: '17:30', alimentos: 'Whey protein, carboidrato rápido', proteina: '35g', carbos: '50g', gordura: '3g' },
      { nome: 'Jantar', hora: '20:00', alimentos: 'Salmão, batata doce, legumes', proteina: '45g', carbos: '75g', gordura: '15g' },
    ]
  }
}

export default function DietPage() {
  const params = useParams()
  const dietId = params.id as string
  const diet = dietsData[dietId]
  const [completedMeals, setCompletedMeals] = useState<string[]>([])

  if (!diet) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-text mb-4">Dieta não encontrada</h1>
          <Link href="/" className="text-primary hover:underline">Voltar para início</Link>
        </div>
      </div>
    )
  }

  const toggleMeal = (mealName: string) => {
    setCompletedMeals(prev =>
      prev.includes(mealName)
        ? prev.filter(m => m !== mealName)
        : [...prev, mealName]
    )
  }

  const progressPercent = (completedMeals.length / diet.refeicoes.length) * 100

  return (
    <main className="min-h-screen bg-gradient-to-b from-background via-card to-background">
      <div className="container mx-auto px-4 py-8">
        <BackButton />
        
        <div className={`bg-gradient-to-r ${diet.color} rounded-lg p-8 mb-8 text-white`}>
          <div className="flex items-center gap-3 mb-4">
            <Apple className="w-8 h-8" />
            <h1 className="text-4xl font-bold">{diet.name}</h1>
          </div>
          <p className="text-white/90 mb-6">{diet.description}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-white/70 text-sm">Calorias Diárias</p>
              <p className="text-2xl font-bold">{diet.calorias}</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-white/70 text-sm">Proteína</p>
              <p className="text-2xl font-bold">{diet.macros.proteina}</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-white/70 text-sm">Carboidrato</p>
              <p className="text-2xl font-bold">{diet.macros.carboidrato}</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-white/70 text-sm">Gordura</p>
              <p className="text-2xl font-bold">{diet.macros.gordura}</p>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Progresso do Dia</h2>
          <div className="w-full bg-card rounded-lg h-4 overflow-hidden">
            <div
              className="bg-primary h-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
          <p className="text-sm text-muted-foreground mt-2">{completedMeals.length} de {diet.refeicoes.length} refeições concluídas</p>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-bold mb-6">Refeições do Dia</h2>
          {diet.refeicoes.map((refeicao: any, idx: number) => (
            <div
              key={idx}
              onClick={() => toggleMeal(refeicao.nome)}
              className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
                completedMeals.includes(refeicao.nome)
                  ? 'border-primary bg-primary/10'
                  : 'border-card bg-card hover:border-primary/50'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-text">{refeicao.nome}</h3>
                  <p className="text-sm text-muted-foreground">{refeicao.hora}</p>
                </div>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  completedMeals.includes(refeicao.nome)
                    ? 'bg-primary border-primary'
                    : 'border-muted-foreground'
                }`}>
                  {completedMeals.includes(refeicao.nome) && (
                    <span className="text-white text-sm font-bold">✓</span>
                  )}
                </div>
              </div>
              
              <p className="text-muted-foreground mb-4">{refeicao.alimentos}</p>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-background rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Proteína</p>
                  <p className="text-lg font-bold text-primary">{refeicao.proteina}</p>
                </div>
                <div className="bg-background rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Carboidrato</p>
                  <p className="text-lg font-bold text-primary">{refeicao.carbos}</p>
                </div>
                <div className="bg-background rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Gordura</p>
                  <p className="text-lg font-bold text-primary">{refeicao.gordura}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
