'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Dumbbell, Apple, MapPin, ShoppingBag, Filter } from 'lucide-react'
import MuscleCard from '@/components/muscle-card'
import DietCard from '@/components/diet-card'
import Header from '@/components/header'

const workoutPlans = [
  { id: 'abcd', name: 'ABCD Split', description: '4 dias - Treino avançado', level: 'avançado', days: 4, color: 'from-red-500 to-pink-600' },
  { id: 'ppl', name: 'Push/Pull/Legs', description: '3-6 dias - Ideal para hipertrofia', level: 'intermediário', days: 6, color: 'from-blue-500 to-purple-600' },
  { id: 'full-body', name: 'Full Body', description: '3 dias - Treino completo', level: 'iniciante', days: 3, color: 'from-green-500 to-emerald-600' },
  { id: 'upper-lower', name: 'Upper/Lower', description: '4 dias - Equilibrado', level: 'intermediário', days: 4, color: 'from-orange-500 to-yellow-600' },
]

const experienceLevels = [
  { id: 'iniciante', name: 'Iniciante', exercises: 'Exercícios básicos' },
  { id: 'intermediario', name: 'Intermediário', exercises: 'Treinos variados' },
  { id: 'avancado', name: 'Avançado', exercises: 'Treinos intensos' },
]

const muscles = [
  { id: 'peito', name: 'Peito', color: 'from-orange-500 to-red-600', exercises: 10 },
  { id: 'costas', name: 'Costas', color: 'from-blue-500 to-cyan-600', exercises: 10 },
  { id: 'pernas', name: 'Pernas', color: 'from-purple-500 to-pink-600', exercises: 12 },
  { id: 'ombros', name: 'Ombros', color: 'from-yellow-500 to-orange-600', exercises: 9 },
  { id: 'bracos', name: 'Braços', color: 'from-red-500 to-pink-600', exercises: 10 },
  { id: 'abdomen', name: 'Abdômen', color: 'from-green-500 to-emerald-600', exercises: 8 },
]

const diets = [
  { id: 'hipertrofia', name: 'Hipertrofia', color: 'from-red-600 to-pink-600', meals: 5, calorias: '3000-3500' },
  { id: 'definicao', name: 'Definição', color: 'from-blue-600 to-cyan-600', meals: 4, calorias: '1800-2200' },
  { id: 'manutencao', name: 'Manutenção', color: 'from-green-600 to-emerald-600', meals: 4, calorias: '2300-2700' },
  { id: 'bulking', name: 'Bulking', color: 'from-orange-600 to-yellow-600', meals: 6, calorias: '3500-4000' },
  { id: 'cutting-extremo', name: 'Cutting Extremo', color: 'from-slate-600 to-slate-700', meals: 3, calorias: '1500-1800' },
  { id: 'emagrecimento', name: 'Emagrecimento', color: 'from-cyan-600 to-blue-700', meals: 4, calorias: '1600-2000' },
  { id: 'recomposicao', name: 'Recomposição', color: 'from-violet-600 to-purple-700', meals: 5, calorias: '2200-2600' },
  { id: 'maintenance-alto-atleta', name: 'Manutenção Alto Atleta', color: 'from-amber-600 to-orange-700', meals: 6, calorias: '3000-3500' },
]

export default function Home() {
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null)
  const [showFilters, setShowFilters] = useState(false)

  const filteredMuscles = selectedLevel 
    ? muscles.filter(muscle => muscle.id === selectedLevel)
    : muscles

  return (
    <>
      <Header />
      <main className="min-h-screen bg-gradient-to-b from-background via-card to-background">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Dumbbell className="w-10 h-10 text-primary" />
              <h1 className="text-4xl md:text-5xl font-bold text-text-balance">
                <span className="text-primary">FitFlow</span> Academy
              </h1>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Treinos completos e personalizados para cada grupo muscular. Escolha seu nível, tipo de treino e comece agora!
            </p>
          </div>

          <div className="mb-20">
            <h2 className="text-3xl font-bold mb-8 flex items-center gap-2">
              <Dumbbell className="w-8 h-8 text-primary" />
              Escolha seu Plano de Treino
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {workoutPlans.map((plan) => (
                <Link key={plan.id} href={`/plano-treino/${plan.id}`}>
                  <div className={`bg-gradient-to-br ${plan.color} rounded-xl p-6 h-40 flex flex-col justify-between hover:shadow-xl transition-shadow cursor-pointer transform hover:scale-105 duration-300`}>
                    <div>
                      <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
                      <p className="text-white/80 text-sm">{plan.description}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="bg-white/20 px-3 py-1 rounded-full text-white text-xs font-semibold">{plan.days} dias</span>
                      <span className="text-white/90 text-xs capitalize">{plan.level}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          <div className="mb-20">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold flex items-center gap-2">
                <Filter className="w-8 h-8 text-primary" />
                Treinos por Nível
              </h2>
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
              >
                {showFilters ? 'Esconder' : 'Mostrar'} Filtros
              </button>
            </div>
            
            {showFilters && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 p-6 bg-card rounded-xl border border-primary/20">
                {experienceLevels.map((level) => (
                  <button
                    key={level.id}
                    onClick={() => setSelectedLevel(selectedLevel === level.id ? null : level.id)}
                    className={`p-4 rounded-lg transition-all ${
                      selectedLevel === level.id
                        ? 'bg-primary text-white ring-2 ring-primary/50'
                        : 'bg-card hover:bg-card/80 text-foreground'
                    }`}
                  >
                    <p className="font-semibold">{level.name}</p>
                    <p className="text-sm text-muted-foreground">{level.exercises}</p>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="mb-20">
            <h2 className="text-3xl font-bold mb-8">Treinos por Grupo Muscular</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMuscles.map((muscle) => (
                <Link key={muscle.id} href={`/musculo/${muscle.id}`}>
                  <MuscleCard muscle={muscle} />
                </Link>
              ))}
            </div>
          </div>

          {/* Academias Próximas */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold mb-8 flex items-center gap-2">
              <MapPin className="w-8 h-8 text-primary" />
              Academias Próximas
            </h2>
            <Link href="/academias">
              <div className="bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl p-8 hover:shadow-xl transition-shadow cursor-pointer">
                <p className="text-white text-lg font-semibold mb-2">Encontre academias perto de você</p>
                <p className="text-cyan-100">Localize e explore as melhores academias na sua região</p>
              </div>
            </Link>
          </div>

          {/* Loja FitFlow */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold mb-8 flex items-center gap-2">
              <ShoppingBag className="w-8 h-8 text-primary" />
              Loja FitFlow
            </h2>
            <Link href="/loja">
              <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl p-8 hover:shadow-xl transition-shadow cursor-pointer">
                <p className="text-white text-lg font-semibold mb-2">Acesse nossa loja</p>
                <p className="text-emerald-100">Suplementos, roupas, equipamentos e muito mais para sua jornada fitness</p>
              </div>
            </Link>
          </div>

          {/* Planos Nutricionais */}
          <div>
            <h2 className="text-3xl font-bold mb-8 flex items-center gap-2">
              <Apple className="w-8 h-8 text-primary" />
              Planos Nutricionais
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {diets.map((diet) => (
                <Link key={diet.id} href={`/dieta/${diet.id}`}>
                  <DietCard diet={diet} />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
