import { notFound } from 'next/navigation'
import ExerciseList from '@/components/exercise-list'
import Header from '@/components/header'
import BackButton from '@/components/back-button'

const muscleData: Record<string, any> = {
  peito: {
    name: 'Peito',
    color: 'from-orange-500 to-red-600',
    exercises: [
      { id: 1, name: 'Supino Reto', series: 4, reps: '8-10', rest: '2-3 min', difficulty: 'Intermediário', videoId: 'dQw4w9WgXcQ' },
      { id: 2, name: 'Supino Inclinado', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'j3kHKYvXQXc' },
      { id: 3, name: 'Crucifixo na Máquina', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'n1t7rUhJL3w' },
      { id: 4, name: 'Supino com Halteres', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'QGAkrjSLqYU' },
      { id: 5, name: 'Flexão de Braços', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'IODxDxX7oi0' },
      { id: 6, name: 'Pec Deck', series: 3, reps: '12-15', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'ryQb3kOzxEk' },
      { id: 7, name: 'Supino Declinado', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: '6-OhUWUbQzg' },
      { id: 8, name: 'Crucifixo com Halteres', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'k-uOrtZBhAk' },
      { id: 9, name: 'Flexão com Peso', series: 3, reps: '8-12', rest: '1-2 min', difficulty: 'Avançado', videoId: 'HG5e7f4KjXE' },
      { id: 10, name: 'Cable Crossover', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'tLXs4FwK00E' },
    ]
  },
  costas: {
    name: 'Costas',
    color: 'from-blue-500 to-cyan-600',
    exercises: [
      { id: 1, name: 'Barra Fixa', series: 4, reps: '6-12', rest: '2-3 min', difficulty: 'Avançado', videoId: '1I1H1rCYo9o' },
      { id: 2, name: 'Puxada na Frente', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'JEy0ftW30Qs' },
      { id: 3, name: 'Rosca Direta Barra', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'kvqRz2uj7aI' },
      { id: 4, name: 'Remada Máquina', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'cHA8qXaPHEo' },
      { id: 5, name: 'Puxada por Trás do Pescoço', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'c7VdM4V0uu8' },
      { id: 6, name: 'Voador Inverso', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'GEn5M-B8B4A' },
      { id: 7, name: 'Rosca Inversa Barra', series: 3, reps: '8-10', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'fv4p9VRi1BY' },
      { id: 8, name: 'Remada com Halteres', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'p1TrSHwFOvo' },
      { id: 9, name: 'Puxada Aberta', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'Kv3rNVvM0IE' },
      { id: 10, name: 'Remada Unilateral', series: 3, reps: '8-10', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'Y88LF0Al9yc' },
    ]
  },
  pernas: {
    name: 'Pernas',
    color: 'from-purple-500 to-pink-600',
    exercises: [
      { id: 1, name: 'Agachamento Livre', series: 4, reps: '6-10', rest: '2-3 min', difficulty: 'Avançado', videoId: 'Dy28eq2PjlU' },
      { id: 2, name: 'Leg Press', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'D8d6gNTfJh8' },
      { id: 3, name: 'Extensora de Pernas', series: 3, reps: '12-15', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'xbXfEu8dEr8' },
      { id: 4, name: 'Flexora de Pernas', series: 3, reps: '12-15', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'DpF3pFdHgZ8' },
      { id: 5, name: 'Afundo com Halteres', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'PvXfEWrEJcE' },
      { id: 6, name: 'Adutor/Abdtor Máquina', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'eFUjJFVYHqI' },
      { id: 7, name: 'Panturrilha na Máquina', series: 3, reps: '15-20', rest: '1 min', difficulty: 'Iniciante', videoId: 'PZsqcNLO1LQ' },
      { id: 8, name: 'Hack Machine', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'qPp3JTiVw-c' },
      { id: 9, name: 'Agachamento Bulgaro', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'hbljLdZCnmM' },
      { id: 10, name: 'Cadeira Extensora', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'aIVmjKHhWZs' },
      { id: 11, name: 'Leg Curl Deitado', series: 3, reps: '12-15', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'UqzK-xXgH-M' },
      { id: 12, name: 'Sapata na Máquina', series: 3, reps: '15-20', rest: '1 min', difficulty: 'Iniciante', videoId: 'AEkIQlJxoUU' },
    ]
  },
  ombros: {
    name: 'Ombros',
    color: 'from-yellow-500 to-orange-600',
    exercises: [
      { id: 1, name: 'Desenvolvimento Livre', series: 4, reps: '6-8', rest: '2-3 min', difficulty: 'Avançado', videoId: 'qKcNy9Mh-cQ' },
      { id: 2, name: 'Desenvolvimento Máquina', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: '0NyRt_nSk58' },
      { id: 3, name: 'Elevação Lateral', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: '3VczyD0YwDc' },
      { id: 4, name: 'Elevação Frontal', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'GKMpYjJ3k74' },
      { id: 5, name: 'Encolhimento de Ombros', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Iniciante', videoId: 'Pjr_U0wvkNg' },
      { id: 6, name: 'Desenvolvimento com Halteres', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'q3IqC0wJI8U' },
      { id: 7, name: 'Elevação Lateral Máquina', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'qU0G5nnbLlU' },
      { id: 8, name: 'Elevação Frontal Cabo', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'BKJDNhZpgQA' },
      { id: 9, name: 'Encolhimento com Halteres', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'PNQhT4-B3BQ' },
    ]
  },
  bracos: {
    name: 'Braços',
    color: 'from-red-500 to-pink-600',
    exercises: [
      { id: 1, name: 'Rosca Direta Halteres', series: 3, reps: '8-10', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'ykJmrsCL4LQ' },
      { id: 2, name: 'Rosca Direta Barra', series: 3, reps: '8-10', rest: '2 min', difficulty: 'Intermediário', videoId: 'zC3nLlEvin4' },
      { id: 3, name: 'Rosca Concentrada', series: 3, reps: '10-12', rest: '1 min', difficulty: 'Iniciante', videoId: 'FOeRQkJSYbQ' },
      { id: 4, name: 'Tríceps Corda', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'anrDZ5Q9Clc' },
      { id: 5, name: 'Tríceps Halteres', series: 3, reps: '10-12', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'V6FcKjd52LU' },
      { id: 6, name: 'Tríceps Máquina', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'UKLkR_Qf9Gg' },
      { id: 7, name: 'Rosca Inversa', series: 3, reps: '8-10', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'jSvZkYvVS94' },
      { id: 8, name: 'Tríceps Banco', series: 3, reps: '8-10', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'nEf2XO59MCU' },
      { id: 9, name: 'Rosca Martelo', series: 3, reps: '10-12', rest: '1 min', difficulty: 'Intermediário', videoId: '0Gvn-d0Xnio' },
      { id: 10, name: 'Tríceps Reverso Corda', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Iniciante', videoId: 'H_E76UqkXfQ' },
    ]
  },
  abdomen: {
    name: 'Abdômen',
    color: 'from-green-500 to-emerald-600',
    exercises: [
      { id: 1, name: 'Abdominal no Banco', series: 3, reps: '15-20', rest: '1 min', difficulty: 'Iniciante', videoId: 'wCqj7r_7osw' },
      { id: 2, name: 'Abdominal na Máquina', series: 3, reps: '15-20', rest: '1 min', difficulty: 'Iniciante', videoId: 'j-EML91XCPU' },
      { id: 3, name: 'Rosca Abdominal', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Intermediário', videoId: 'sHct33xu7Zc' },
      { id: 4, name: 'Leg Raise', series: 3, reps: '12-15', rest: '1-2 min', difficulty: 'Intermediário', videoId: 'JB2DIgg6DCE' },
      { id: 5, name: 'Prancha', series: 3, reps: '30-60s', rest: '1 min', difficulty: 'Iniciante', videoId: 'ASdvN_XKuqo' },
      { id: 6, name: 'Prancha Dinâmica', series: 3, reps: '12-15', rest: '1 min', difficulty: 'Intermediário', videoId: 'xxKfJZzfR-o' },
      { id: 7, name: 'Bicicleta Abdominal', series: 3, reps: '20-30', rest: '1 min', difficulty: 'Iniciante', videoId: '1uDfGV4mXcU' },
      { id: 8, name: 'Rotação Russa', series: 3, reps: '20', rest: '1 min', difficulty: 'Intermediário', videoId: '6v2K6k_LfGc' },
    ]
  }
}

interface PageProps {
  params: Promise<{ id: string }>
}

export default async function MusclePage({ params }: PageProps) {
  const { id } = await params
  const muscle = muscleData[id]

  if (!muscle) {
    notFound()
  }

  return (
    <>
      <Header />
      <main className="min-h-screen bg-gradient-to-b from-background via-card to-background">
        <div className="container mx-auto px-4 py-8">
          <BackButton />
          
          <div className={`bg-gradient-to-r ${muscle.color} rounded-2xl p-12 mb-12 text-white shadow-lg`}>
            <h1 className="text-5xl font-bold mb-2">{muscle.name}</h1>
            <p className="text-lg opacity-90">{muscle.exercises.length} exercícios para treinar completamente</p>
          </div>

          <ExerciseList exercises={muscle.exercises} />
        </div>
      </main>
    </>
  )
}
