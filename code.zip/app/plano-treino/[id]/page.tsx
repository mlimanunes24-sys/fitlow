'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Dumbbell, Clock, Zap } from 'lucide-react'
import BackButton from '@/components/back-button'

const workoutDetails: Record<string, any> = {
  abcd: {
    name: 'ABCD Split',
    description: 'Treino avançado de 4 dias com foco em hipertrofia',
    days: [
      {
        day: 'Dia A - Peito e Tríceps',
        color: 'from-orange-500 to-red-600',
        exercises: [
          { name: 'Supino Reto', sets: '4x8', rest: '2-3 min' },
          { name: 'Supino Inclinado', sets: '3x10', rest: '90 seg' },
          { name: 'Rosca Francesa', sets: '3x10', rest: '90 seg' },
          { name: 'Tríceps na Polia', sets: '3x12', rest: '60 seg' },
        ]
      },
      {
        day: 'Dia B - Costas e Bíceps',
        color: 'from-blue-500 to-cyan-600',
        exercises: [
          { name: 'Barra Fixa', sets: '4x8', rest: '2-3 min' },
          { name: 'Rosca Direita', sets: '4x10', rest: '90 seg' },
          { name: 'Rosca Inversa', sets: '3x10', rest: '90 seg' },
          { name: 'Encolhimento', sets: '3x12', rest: '60 seg' },
        ]
      },
      {
        day: 'Dia C - Pernas',
        color: 'from-purple-500 to-pink-600',
        exercises: [
          { name: 'Agachamento Livre', sets: '4x8', rest: '3 min' },
          { name: 'Leg Press', sets: '3x10', rest: '2 min' },
          { name: 'Cadeira Extensora', sets: '3x12', rest: '90 seg' },
          { name: 'Leg Curl', sets: '3x12', rest: '90 seg' },
        ]
      },
      {
        day: 'Dia D - Ombros e Abdômen',
        color: 'from-yellow-500 to-orange-600',
        exercises: [
          { name: 'Desenvolvimento Militar', sets: '4x8', rest: '2-3 min' },
          { name: 'Rosca Lateral', sets: '3x12', rest: '60 seg' },
          { name: 'Elevação Frontal', sets: '3x12', rest: '60 seg' },
          { name: 'Abdominal na Máquina', sets: '3x15', rest: '60 seg' },
        ]
      },
    ]
  },
  ppl: {
    name: 'Push/Pull/Legs',
    description: 'Treino de 6 dias com foco em movimentos empurrados, puxados e pernas',
    days: [
      {
        day: 'Push A - Peito, Ombros, Tríceps',
        color: 'from-red-500 to-pink-600',
        exercises: [
          { name: 'Supino Reto', sets: '4x6-8', rest: '3 min' },
          { name: 'Desenvolvimento Militar', sets: '3x8-10', rest: '2 min' },
          { name: 'Supino Inclinado Haltere', sets: '3x8-10', rest: '90 seg' },
          { name: 'Rosca Lateral', sets: '3x12', rest: '60 seg' },
        ]
      },
      {
        day: 'Pull A - Costas e Bíceps',
        color: 'from-blue-500 to-purple-600',
        exercises: [
          { name: 'Barra Fixa', sets: '4x6-8', rest: '3 min' },
          { name: 'Rosca Direta', sets: '3x8-10', rest: '2 min' },
          { name: 'Puxada Frontal', sets: '3x10-12', rest: '90 seg' },
          { name: 'Remada Baixa', sets: '3x10-12', rest: '90 seg' },
        ]
      },
      {
        day: 'Legs - Pernas',
        color: 'from-purple-500 to-pink-600',
        exercises: [
          { name: 'Agachamento Livre', sets: '4x6-8', rest: '3 min' },
          { name: 'Leg Press', sets: '3x8-10', rest: '2-3 min' },
          { name: 'Leg Curl', sets: '3x10-12', rest: '90 seg' },
          { name: 'Extensão Quadríceps', sets: '3x12', rest: '90 seg' },
        ]
      },
      {
        day: 'Push B - Peito, Ombros, Tríceps',
        color: 'from-orange-500 to-red-600',
        exercises: [
          { name: 'Supino Inclinado', sets: '4x6-8', rest: '3 min' },
          { name: 'Rosca Francesa', sets: '3x8-10', rest: '2 min' },
          { name: 'Crucifixo', sets: '3x10-12', rest: '90 seg' },
          { name: 'Tríceps Corda', sets: '3x12', rest: '60 seg' },
        ]
      },
      {
        day: 'Pull B - Costas e Bíceps',
        color: 'from-cyan-500 to-blue-600',
        exercises: [
          { name: 'Remada com Barra', sets: '4x6-8', rest: '3 min' },
          { name: 'Rosca Inversa', sets: '3x8-10', rest: '2 min' },
          { name: 'Serrote', sets: '3x10-12', rest: '90 seg' },
          { name: 'Face Pull', sets: '3x12', rest: '60 seg' },
        ]
      },
      {
        day: 'Legs B - Pernas',
        color: 'from-green-500 to-emerald-600',
        exercises: [
          { name: 'Leg Press', sets: '4x6-8', rest: '3 min' },
          { name: 'Agachamento Búlgaro', sets: '3x8-10', rest: '2 min' },
          { name: 'Extensão Quadríceps', sets: '3x12', rest: '90 seg' },
          { name: 'Cadeira Adutora', sets: '3x12', rest: '60 seg' },
        ]
      },
    ]
  },
  'full-body': {
    name: 'Full Body',
    description: 'Treino de 3 dias com todo corpo em cada sessão',
    days: [
      {
        day: 'Dia 1 - Full Body A',
        color: 'from-green-500 to-emerald-600',
        exercises: [
          { name: 'Agachamento', sets: '3x8', rest: '2-3 min' },
          { name: 'Supino', sets: '3x8', rest: '2 min' },
          { name: 'Barra Fixa', sets: '3x8', rest: '2 min' },
          { name: 'Rosca Direta', sets: '3x10', rest: '90 seg' },
        ]
      },
      {
        day: 'Dia 2 - Full Body B',
        color: 'from-emerald-500 to-teal-600',
        exercises: [
          { name: 'Leg Press', sets: '3x10', rest: '2-3 min' },
          { name: 'Supino Inclinado', sets: '3x8', rest: '2 min' },
          { name: 'Remada', sets: '3x8', rest: '2 min' },
          { name: 'Rosca Francesa', sets: '3x10', rest: '90 seg' },
        ]
      },
      {
        day: 'Dia 3 - Full Body C',
        color: 'from-teal-500 to-cyan-600',
        exercises: [
          { name: 'Agachamento Búlgaro', sets: '3x10', rest: '90 seg' },
          { name: 'Crucifixo', sets: '3x10', rest: '90 seg' },
          { name: 'Puxada Frontal', sets: '3x10', rest: '90 seg' },
          { name: 'Abdominal', sets: '3x15', rest: '60 seg' },
        ]
      },
    ]
  },
  'upper-lower': {
    name: 'Upper/Lower',
    description: 'Treino de 4 dias com foco em membros superiores e inferiores',
    days: [
      {
        day: 'Dia 1 - Upper Power',
        color: 'from-blue-500 to-purple-600',
        exercises: [
          { name: 'Supino Reto', sets: '4x5', rest: '3 min' },
          { name: 'Barra Fixa', sets: '4x5', rest: '3 min' },
          { name: 'Rosca Direta', sets: '3x8', rest: '90 seg' },
          { name: 'Rosca Francesa', sets: '3x8', rest: '90 seg' },
        ]
      },
      {
        day: 'Dia 2 - Lower Power',
        color: 'from-purple-500 to-pink-600',
        exercises: [
          { name: 'Agachamento Livre', sets: '4x5', rest: '3 min' },
          { name: 'Deadlift Romeno', sets: '3x8', rest: '2 min' },
          { name: 'Leg Curl', sets: '3x10', rest: '90 seg' },
          { name: 'Panturrilha', sets: '3x15', rest: '60 seg' },
        ]
      },
      {
        day: 'Dia 3 - Upper Hypertrophy',
        color: 'from-orange-500 to-red-600',
        exercises: [
          { name: 'Supino Inclinado', sets: '3x8-10', rest: '2 min' },
          { name: 'Remada', sets: '3x8-10', rest: '2 min' },
          { name: 'Rosca Lateral', sets: '3x12', rest: '60 seg' },
          { name: 'Tríceps Corda', sets: '3x12', rest: '60 seg' },
        ]
      },
      {
        day: 'Dia 4 - Lower Hypertrophy',
        color: 'from-red-500 to-pink-600',
        exercises: [
          { name: 'Leg Press', sets: '3x10-12', rest: '2 min' },
          { name: 'Extensão Quad', sets: '3x12', rest: '90 seg' },
          { name: 'Leg Curl', sets: '3x12', rest: '90 seg' },
          { name: 'Agachamento Búlgaro', sets: '3x12', rest: '90 seg' },
        ]
      },
    ]
  },
}

export default function WorkoutPlanPage({ params }: { params: { id: string } }) {
  const [completedExercises, setCompletedExercises] = useState<Record<string, boolean>>({})
  const plan = workoutDetails[params.id]

  if (!plan) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background via-card to-background">
        <div className="container mx-auto px-4 py-12">
          <BackButton />
          <div className="text-center py-20">
            <h1 className="text-3xl font-bold text-foreground">Plano não encontrado</h1>
          </div>
        </div>
      </div>
    )
  }

  const toggleExercise = (exerciseId: string) => {
    setCompletedExercises(prev => ({
      ...prev,
      [exerciseId]: !prev[exerciseId]
    }))
  }

  const totalExercises = plan.days.reduce((sum: number, day: any) => sum + day.exercises.length, 0)
  const completedCount = Object.values(completedExercises).filter(Boolean).length
  const progress = Math.round((completedCount / totalExercises) * 100)

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-card to-background">
      <div className="container mx-auto px-4 py-12">
        <BackButton />

        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">{plan.name}</h1>
          <p className="text-lg text-muted-foreground mb-6">{plan.description}</p>

          <div className="w-full bg-card rounded-lg p-4 border border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">Progresso geral</span>
              <span className="text-primary font-bold">{progress}%</span>
            </div>
            <div className="w-full bg-background rounded-full h-3 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-primary to-primary/60 h-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-sm text-muted-foreground mt-2">{completedCount} de {totalExercises} exercícios completos</p>
          </div>
        </div>

        <div className="space-y-8">
          {plan.days.map((day: any, index: number) => (
            <div key={index} className={`bg-gradient-to-br ${day.color} rounded-xl overflow-hidden shadow-lg`}>
              <div className="bg-black/30 px-8 py-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Dumbbell className="w-6 h-6" />
                  {day.day}
                </h2>
              </div>
              <div className="p-8 bg-card/50 backdrop-blur">
                <div className="space-y-4">
                  {day.exercises.map((exercise: any, exIdx: number) => {
                    const exerciseId = `${index}-${exIdx}`
                    const isCompleted = completedExercises[exerciseId]
                    return (
                      <button
                        key={exerciseId}
                        onClick={() => toggleExercise(exerciseId)}
                        className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                          isCompleted
                            ? 'border-primary bg-primary/10'
                            : 'border-primary/20 bg-card hover:border-primary/40'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                            isCompleted ? 'bg-primary border-primary' : 'border-primary/40'
                          }`}>
                            {isCompleted && <span className="text-white font-bold">✓</span>}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg">{exercise.name}</h3>
                            <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Zap className="w-4 h-4" />
                                {exercise.sets}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                {exercise.rest}
                              </span>
                            </div>
                          </div>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
