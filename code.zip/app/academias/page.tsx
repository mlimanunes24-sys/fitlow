'use client'

import { useState, useEffect } from 'react'
import { MapPin, Phone, Clock, Star, Navigation, Search } from 'lucide-react'
import Link from 'next/link'
import Header from '@/components/header'

interface Gym {
  id: number
  name: string
  address: string
  phone: string
  rating: number
  reviews: number
  hours: string
  distance: number
  coords: { lat: number; lng: number }
}

const mockGyms: Gym[] = [
  {
    id: 1,
    name: 'FitFlow Premium',
    address: 'Av. Paulista, 1000',
    phone: '(11) 3333-1111',
    rating: 4.8,
    reviews: 245,
    hours: '06:00 - 23:00',
    distance: 0.5,
    coords: { lat: -23.5505, lng: -46.6333 }
  },
  {
    id: 2,
    name: 'Iron Gym',
    address: 'R. Augusta, 2500',
    phone: '(11) 3333-2222',
    rating: 4.6,
    reviews: 189,
    hours: '05:30 - 22:30',
    distance: 1.2,
    coords: { lat: -23.5495, lng: -46.6323 }
  },
  {
    id: 3,
    name: 'Power Center',
    address: 'Av. Rebouças, 3200',
    phone: '(11) 3333-3333',
    rating: 4.7,
    reviews: 312,
    hours: '06:00 - 23:30',
    distance: 2.1,
    coords: { lat: -23.5515, lng: -46.6343 }
  },
  {
    id: 4,
    name: 'Steel Warriors',
    address: 'R. Fradique Coutinho, 1500',
    phone: '(11) 3333-4444',
    rating: 4.5,
    reviews: 156,
    hours: '07:00 - 22:00',
    distance: 1.8,
    coords: { lat: -23.5485, lng: -46.6313 }
  },
  {
    id: 5,
    name: 'Elite Fitness',
    address: 'Av. Higienópolis, 500',
    phone: '(11) 3333-5555',
    rating: 4.9,
    reviews: 428,
    hours: '06:00 - 00:00',
    distance: 0.8,
    coords: { lat: -23.5525, lng: -46.6353 }
  },
  {
    id: 6,
    name: 'CrossFit Pro',
    address: 'R. Bandeira Paulista, 1000',
    phone: '(11) 3333-6666',
    rating: 4.4,
    reviews: 98,
    hours: '05:00 - 22:00',
    distance: 1.5,
    coords: { lat: -23.5475, lng: -46.6303 }
  },
]

export default function AcademiasPage() {
  const [gyms, setGyms] = useState<Gym[]>(mockGyms)
  const [searchTerm, setSearchTerm] = useState('')
  const [sortBy, setSortBy] = useState<'distance' | 'rating'>('distance')
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        })
      })
    }
  }, [])

  const filteredAndSortedGyms = gyms
    .filter(gym => 
      gym.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      gym.address.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'distance') {
        return a.distance - b.distance
      }
      return b.rating - a.rating
    })

  return (
    <>
      <Header />
      <main className="min-h-screen bg-gradient-to-b from-background via-card to-background">
        <div className="container mx-auto px-4 py-12">
          <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-8">
            <span>← Voltar</span>
          </Link>

          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <MapPin className="w-10 h-10 text-primary" />
              <h1 className="text-4xl font-bold">Academias Próximas</h1>
            </div>
            <p className="text-lg text-muted-foreground">Encontre as melhores academias perto de você</p>
          </div>

          {/* Filtros e busca */}
          <div className="bg-card rounded-xl p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Buscar academia</label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="Nome ou endereço..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-lg text-foreground placeholder-muted-foreground"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Ordenar por</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'distance' | 'rating')}
                  className="w-full px-4 py-2 bg-input border border-border rounded-lg text-foreground"
                >
                  <option value="distance">Distância</option>
                  <option value="rating">Avaliação</option>
                </select>
              </div>
              <div className="flex items-end">
                <button
                  onClick={() => {
                    if (navigator.geolocation) {
                      navigator.geolocation.getCurrentPosition((position) => {
                        setUserLocation({
                          lat: position.coords.latitude,
                          lng: position.coords.longitude,
                        })
                      })
                    }
                  }}
                  className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
                >
                  <Navigation className="w-4 h-4" />
                  Minha Localização
                </button>
              </div>
            </div>
          </div>

          {/* Lista de academias */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredAndSortedGyms.map((gym) => (
              <div
                key={gym.id}
                className="bg-card rounded-xl p-6 border border-border hover:border-primary transition-colors hover:shadow-xl"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-foreground">{gym.name}</h3>
                    <p className="text-sm text-muted-foreground">{gym.distance} km de distância</p>
                  </div>
                  <div className="flex items-center gap-1 bg-primary/20 px-3 py-1 rounded-full">
                    <Star className="w-4 h-4 text-primary fill-primary" />
                    <span className="font-semibold text-primary">{gym.rating}</span>
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <MapPin className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-sm">{gym.address}</span>
                  </div>
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-sm">{gym.phone}</span>
                  </div>
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <Clock className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-sm">{gym.hours}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <span className="text-sm text-muted-foreground">{gym.reviews} avaliações</span>
                  <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                    Ver Detalhes
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredAndSortedGyms.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-lg text-muted-foreground">Nenhuma academia encontrada</p>
            </div>
          )}
        </div>
      </main>
    </>
  )
}
