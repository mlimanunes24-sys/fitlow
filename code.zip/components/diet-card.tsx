export default function DietCard({ diet }: { diet: any }) {
  return (
    <div className={`bg-gradient-to-br ${diet.color} rounded-lg p-6 hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer h-full flex flex-col justify-between`}>
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">{diet.name}</h3>
        <div className="space-y-2 text-white/90">
          <p>Refeições: <span className="font-semibold">{diet.meals}</span></p>
          <p>Calorias: <span className="font-semibold">{diet.calorias}</span></p>
        </div>
      </div>
      <div className="mt-4 text-white/80 text-sm">
        Clique para ver mais
      </div>
    </div>
  )
}
