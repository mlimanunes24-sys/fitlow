'use client'

import { Check, Play } from 'lucide-react'
import { useState } from 'react'
import ExerciseAnimation from './exercise-animation'

interface ExerciseCardProps {
  exercise: {
    id: number
    name: string
    series: number
    reps: string
    rest: string
    difficulty: string
    videoId?: string
  }
  isCompleted: boolean
  onToggle: () => void
}

export default function ExerciseCard({ exercise, isCompleted, onToggle }: ExerciseCardProps) {
  const [showVideo, setShowVideo] = useState(false)
  const [showAnimation, setShowAnimation] = useState(false)

  const difficultyColor = {
    'Iniciante': 'bg-green-500/10 text-green-300 border-green-500/20',
    'Intermediário': 'bg-yellow-500/10 text-yellow-300 border-yellow-500/20',
    'Avançado': 'bg-red-500/10 text-red-300 border-red-500/20',
  }[exercise.difficulty] || 'bg-gray-500/10 text-gray-300'

  return (
    <div>
      {showAnimation && (
        <ExerciseAnimation exerciseName={exercise.name} onClose={() => setShowAnimation(false)} />
      )}

      {showVideo && exercise.videoId && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 mb-4">
          <div className="bg-card rounded-2xl overflow-hidden shadow-2xl max-w-2xl w-full">
            <div className="flex justify-between items-center p-4 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground">{exercise.name}</h3>
              <button
                onClick={() => setShowVideo(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                ✕
              </button>
            </div>
            <div className="aspect-video bg-black">
              <iframe
                width="100%"
                height="100%"
                src={`https://www.youtube.com/embed/${exercise.videoId}`}
                title={exercise.name}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      )}

      <button
        onClick={onToggle}
        className={`relative group w-full p-6 rounded-xl border-2 transition-all duration-300 text-left ${
          isCompleted
            ? 'bg-primary/10 border-primary'
            : 'bg-card border-border hover:border-primary hover:bg-card/80'
        }`}
      >
        <div className="flex items-start gap-4">
          <div className={`flex-shrink-0 w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
            isCompleted
              ? 'bg-primary border-primary'
              : 'border-muted-foreground group-hover:border-primary'
          }`}>
            {isCompleted && <Check className="w-5 h-5 text-primary-foreground" />}
          </div>

          <div className="flex-1">
            <h3 className={`text-xl font-semibold mb-2 ${isCompleted ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
              {exercise.name}
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Séries</p>
                <p className="text-lg font-bold text-primary">{exercise.series}x</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Repetições</p>
                <p className="text-lg font-bold text-accent">{exercise.reps}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Descanso</p>
                <p className="text-lg font-bold text-foreground">{exercise.rest}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Nível</p>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold border ${difficultyColor}`}>
                  {exercise.difficulty}
                </span>
              </div>
            </div>
          </div>

          <div className="flex-shrink-0 flex gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation()
                setShowAnimation(true)
              }}
              className="flex-shrink-0 p-3 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary transition-colors"
              title="Ver animação com bonecos"
            >
              <Play className="w-5 h-5 fill-current" />
            </button>
            {exercise.videoId && (
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setShowVideo(true)
                }}
                className="flex-shrink-0 p-3 rounded-lg bg-accent/10 hover:bg-accent/20 text-accent transition-colors"
                title="Assistir vídeo no YouTube"
              >
                <Play className="w-5 h-5 fill-current" />
              </button>
            )}
          </div>
        </div>
      </button>
    </div>
  )
}
