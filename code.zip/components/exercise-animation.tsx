'use client'

import { useState } from 'react'
import { Play, Pause } from 'lucide-react'

interface ExerciseAnimationProps {
  exerciseName: string
  onClose: () => void
}

export default function ExerciseAnimation({ exerciseName, onClose }: ExerciseAnimationProps) {
  const [isPlaying, setIsPlaying] = useState(true)

  const animationData: Record<string, { frames: React.ReactNode[] }> = {
    'Supino Reto': {
      frames: [
        // Posição inicial
        <svg key="frame1" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FF6B6B" />
              <stop offset="50%" stopColor="#FF5252" />
              <stop offset="100%" stopColor="#E63946" />
            </linearGradient>
            <linearGradient id="skinGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
            <filter id="shadow1">
              <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3"/>
            </filter>
          </defs>
          {/* Banco */}
          <rect x="50" y="140" width="300" height="80" fill="#2c2c2c" rx="8" filter="url(#shadow1)"/>
          <rect x="40" y="220" width="50" height="150" fill="#3a3a3a" rx="4"/>
          <rect x="330" y="220" width="50" height="150" fill="#3a3a3a" rx="4"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="160" rx="85" ry="60" fill="url(#torsoGrad1)"/>
          
          {/* Cabeça */}
          <circle cx="200" cy="80" r="35" fill="url(#skinGrad1)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="75" r="3" fill="#333"/>
          <circle cx="210" cy="75" r="3" fill="#333"/>
          {/* Olhos */}
          <circle cx="190" cy="75" r="3" fill="#333"/>
          <circle cx="210" cy="75" r="3" fill="#333"/>
          {/* Boca */}
          <path d="M 190 90 Q 200 95 210 90" stroke="#333" strokeWidth="1.5" fill="none"/>
          
          {/* Pescoço */}
          <line x1="200" y1="115" x2="200" y2="140" stroke="url(#skinGrad1)" strokeWidth="18"/>
          
          {/* Braço esquerdo - abaixado */}
          <g>
            <line x1="115" y1="145" x2="60" y2="250" stroke="url(#skinGrad1)" strokeWidth="22" strokeLinecap="round"/>
            <circle cx="60" cy="250" r="12" fill="url(#skinGrad1)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere esquerdo */}
            <rect x="40" y="245" width="35" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="38" cy="250" r="8" fill="#FFB81C"/>
            <circle cx="77" cy="250" r="8" fill="#FFB81C"/>
            <circle cx="36" cy="250" r="5" fill="#FFC93C"/>
            <circle cx="79" cy="250" r="5" fill="#FFC93C"/>
          </g>
          
          {/* Braço direito - abaixado */}
          <g>
            <line x1="285" y1="145" x2="340" y2="250" stroke="url(#skinGrad1)" strokeWidth="22" strokeLinecap="round"/>
            <circle cx="340" cy="250" r="12" fill="url(#skinGrad1)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere direito */}
            <rect x="325" y="245" width="35" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="323" cy="250" r="8" fill="#FFB81C"/>
            <circle cx="362" cy="250" r="8" fill="#FFB81C"/>
            <circle cx="321" cy="250" r="5" fill="#FFC93C"/>
            <circle cx="364" cy="250" r="5" fill="#FFC93C"/>
          </g>
          
          {/* Pernas */}
          <g>
            <line x1="180" y1="220" x2="170" y2="370" stroke="url(#skinGrad1)" strokeWidth="20" strokeLinecap="round"/>
            <line x1="220" y1="220" x2="230" y2="370" stroke="url(#skinGrad1)" strokeWidth="20" strokeLinecap="round"/>
            {/* Pés */}
            <ellipse cx="170" cy="385" rx="15" ry="20" fill="#3a3a3a"/>
            <ellipse cx="230" cy="385" rx="15" ry="20" fill="#3a3a3a"/>
          </g>
        </svg>,
        
        // Posição intermediária
        <svg key="frame2" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FF6B6B" />
              <stop offset="50%" stopColor="#FF5252" />
              <stop offset="100%" stopColor="#E63946" />
            </linearGradient>
            <linearGradient id="skinGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
            <filter id="shadow2">
              <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3"/>
            </filter>
          </defs>
          {/* Banco */}
          <rect x="50" y="140" width="300" height="80" fill="#2c2c2c" rx="8" filter="url(#shadow2)"/>
          <rect x="40" y="220" width="50" height="150" fill="#3a3a3a" rx="4"/>
          <rect x="330" y="220" width="50" height="150" fill="#3a3a3a" rx="4"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="160" rx="85" ry="60" fill="url(#torsoGrad2)"/>
          
          {/* Cabeça */}
          <circle cx="200" cy="80" r="35" fill="url(#skinGrad2)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="75" r="3" fill="#333"/>
          <circle cx="210" cy="75" r="3" fill="#333"/>
          {/* Olhos */}
          <circle cx="190" cy="75" r="3" fill="#333"/>
          <circle cx="210" cy="75" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="115" x2="200" y2="140" stroke="url(#skinGrad2)" strokeWidth="18"/>
          
          {/* Braço esquerdo - intermediário */}
          <g>
            <path d="M 115 145 Q 85 130 70 160" stroke="url(#skinGrad2)" strokeWidth="22" strokeLinecap="round" fill="none"/>
            <circle cx="70" cy="160" r="12" fill="url(#skinGrad2)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere esquerdo */}
            <rect x="48" y="155" width="35" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="46" cy="160" r="8" fill="#FFB81C"/>
            <circle cx="85" cy="160" r="8" fill="#FFB81C"/>
            <circle cx="44" cy="160" r="5" fill="#FFC93C"/>
            <circle cx="87" cy="160" r="5" fill="#FFC93C"/>
          </g>
          
          {/* Braço direito - intermediário */}
          <g>
            <path d="M 285 145 Q 315 130 330 160" stroke="url(#skinGrad2)" strokeWidth="22" strokeLinecap="round" fill="none"/>
            <circle cx="330" cy="160" r="12" fill="url(#skinGrad2)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere direito */}
            <rect x="315" y="155" width="35" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="313" cy="160" r="8" fill="#FFB81C"/>
            <circle cx="352" cy="160" r="8" fill="#FFB81C"/>
            <circle cx="311" cy="160" r="5" fill="#FFC93C"/>
            <circle cx="354" cy="160" r="5" fill="#FFC93C"/>
          </g>
          
          {/* Pernas */}
          <g>
            <line x1="180" y1="220" x2="170" y2="370" stroke="url(#skinGrad2)" strokeWidth="20" strokeLinecap="round"/>
            <line x1="220" y1="220" x2="230" y2="370" stroke="url(#skinGrad2)" strokeWidth="20" strokeLinecap="round"/>
            <ellipse cx="170" cy="385" rx="15" ry="20" fill="#3a3a3a"/>
            <ellipse cx="230" cy="385" rx="15" ry="20" fill="#3a3a3a"/>
          </g>
        </svg>,
        
        // Posição final - braços estendidos
        <svg key="frame3" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FF6B6B" />
              <stop offset="50%" stopColor="#FF5252" />
              <stop offset="100%" stopColor="#E63946" />
            </linearGradient>
            <linearGradient id="skinGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
            <filter id="shadow3">
              <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3"/>
            </filter>
          </defs>
          {/* Banco */}
          <rect x="50" y="140" width="300" height="80" fill="#2c2c2c" rx="8" filter="url(#shadow3)"/>
          <rect x="40" y="220" width="50" height="150" fill="#3a3a3a" rx="4"/>
          <rect x="330" y="220" width="50" height="150" fill="#3a3a3a" rx="4"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="160" rx="85" ry="60" fill="url(#torsoGrad3)"/>
          
          {/* Cabeça */}
          <circle cx="200" cy="80" r="35" fill="url(#skinGrad3)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="75" r="3" fill="#333"/>
          <circle cx="210" cy="75" r="3" fill="#333"/>
          {/* Olhos */}
          <circle cx="190" cy="75" r="3" fill="#333"/>
          <circle cx="210" cy="75" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="115" x2="200" y2="140" stroke="url(#skinGrad3)" strokeWidth="18"/>
          
          {/* Braço esquerdo - estendido */}
          <g>
            <line x1="115" y1="145" x2="25" y2="100" stroke="url(#skinGrad3)" strokeWidth="22" strokeLinecap="round"/>
            <circle cx="25" cy="100" r="12" fill="url(#skinGrad3)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere esquerdo */}
            <rect x="8" y="95" width="35" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="6" cy="100" r="8" fill="#FFB81C"/>
            <circle cx="45" cy="100" r="8" fill="#FFB81C"/>
            <circle cx="4" cy="100" r="5" fill="#FFC93C"/>
            <circle cx="47" cy="100" r="5" fill="#FFC93C"/>
          </g>
          
          {/* Braço direito - estendido */}
          <g>
            <line x1="285" y1="145" x2="375" y2="100" stroke="url(#skinGrad3)" strokeWidth="22" strokeLinecap="round"/>
            <circle cx="375" cy="100" r="12" fill="url(#skinGrad3)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere direito */}
            <rect x="357" y="95" width="35" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="355" cy="100" r="8" fill="#FFB81C"/>
            <circle cx="394" cy="100" r="8" fill="#FFB81C"/>
            <circle cx="353" cy="100" r="5" fill="#FFC93C"/>
            <circle cx="396" cy="100" r="5" fill="#FFC93C"/>
          </g>
          
          {/* Pernas */}
          <g>
            <line x1="180" y1="220" x2="170" y2="370" stroke="url(#skinGrad3)" strokeWidth="20" strokeLinecap="round"/>
            <line x1="220" y1="220" x2="230" y2="370" stroke="url(#skinGrad3)" strokeWidth="20" strokeLinecap="round"/>
            <ellipse cx="170" cy="385" rx="15" ry="20" fill="#3a3a3a"/>
            <ellipse cx="230" cy="385" rx="15" ry="20" fill="#3a3a3a"/>
          </g>
        </svg>,
      ]
    },
    'Agachamento Livre': {
      frames: [
        // Posição inicial - em pé
        <svg key="frame1" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGradAg1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#4ECDC4" />
              <stop offset="100%" stopColor="#44A08D" />
            </linearGradient>
            <linearGradient id="skinGradAg1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
          </defs>
          {/* Cabeça */}
          <circle cx="200" cy="60" r="35" fill="url(#skinGradAg1)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="55" r="3" fill="#333"/>
          <circle cx="210" cy="55" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="95" x2="200" y2="115" stroke="url(#skinGradAg1)" strokeWidth="18"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="145" rx="70" ry="50" fill="url(#torsoGradAg1)"/>
          
          {/* Braços em repouso */}
          <g>
            <line x1="140" y1="130" x2="110" y2="160" stroke="url(#skinGradAg1)" strokeWidth="18" strokeLinecap="round"/>
            <circle cx="110" cy="160" r="10" fill="url(#skinGradAg1)" stroke="#E8B39E" strokeWidth="1"/>
            
            <line x1="260" y1="130" x2="290" y2="160" stroke="url(#skinGradAg1)" strokeWidth="18" strokeLinecap="round"/>
            <circle cx="290" cy="160" r="10" fill="url(#skinGradAg1)" stroke="#E8B39E" strokeWidth="1"/>
          </g>
          
          {/* Coxa esquerda */}
          <line x1="180" y1="195" x2="170" y2="320" stroke="url(#skinGradAg1)" strokeWidth="25" strokeLinecap="round"/>
          {/* Panturrilha esquerda */}
          <line x1="170" y1="320" x2="165" y2="410" stroke="#4A4A4A" strokeWidth="18" strokeLinecap="round"/>
          
          {/* Coxa direita */}
          <line x1="220" y1="195" x2="230" y2="320" stroke="url(#skinGradAg1)" strokeWidth="25" strokeLinecap="round"/>
          {/* Panturrilha direita */}
          <line x1="230" y1="320" x2="235" y2="410" stroke="#4A4A4A" strokeWidth="18" strokeLinecap="round"/>
          
          {/* Pés */}
          <ellipse cx="165" cy="425" rx="18" ry="20" fill="#2a2a2a"/>
          <ellipse cx="235" cy="425" rx="18" ry="20" fill="#2a2a2a"/>
        </svg>,
        
        // Posição intermediária - agachando
        <svg key="frame2" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGradAg2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#4ECDC4" />
              <stop offset="100%" stopColor="#44A08D" />
            </linearGradient>
            <linearGradient id="skinGradAg2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
          </defs>
          {/* Cabeça */}
          <circle cx="200" cy="100" r="35" fill="url(#skinGradAg2)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="95" r="3" fill="#333"/>
          <circle cx="210" cy="95" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="135" x2="200" y2="155" stroke="url(#skinGradAg2)" strokeWidth="18"/>
          
          {/* Tronco inclinado */}
          <ellipse cx="200" cy="190" rx="70" ry="50" fill="url(#torsoGradAg2)"/>
          
          {/* Braços para frente */}
          <g>
            <path d="M 140 170 L 80 150" stroke="url(#skinGradAg2)" strokeWidth="18" strokeLinecap="round" fill="none"/>
            <circle cx="80" cy="150" r="10" fill="url(#skinGradAg2)" stroke="#E8B39E" strokeWidth="1"/>
            
            <path d="M 260 170 L 320 150" stroke="url(#skinGradAg2)" strokeWidth="18" strokeLinecap="round" fill="none"/>
            <circle cx="320" cy="150" r="10" fill="url(#skinGradAg2)" stroke="#E8B39E" strokeWidth="1"/>
          </g>
          
          {/* Coxas flexionadas */}
          <path d="M 185 240 Q 170 280 170 340" stroke="url(#skinGradAg2)" strokeWidth="25" strokeLinecap="round" fill="none"/>
          <path d="M 215 240 Q 230 280 230 340" stroke="url(#skinGradAg2)" strokeWidth="25" strokeLinecap="round" fill="none"/>
          
          {/* Panturrilhas */}
          <line x1="170" y1="340" x2="170" y2="410" stroke="#4A4A4A" strokeWidth="18" strokeLinecap="round"/>
          <line x1="230" y1="340" x2="230" y2="410" stroke="#4A4A4A" strokeWidth="18" strokeLinecap="round"/>
          
          {/* Pés */}
          <ellipse cx="170" cy="425" rx="18" ry="20" fill="#2a2a2a"/>
          <ellipse cx="230" cy="425" rx="18" ry="20" fill="#2a2a2a"/>
        </svg>,
        
        // Posição final - agachado no fundo
        <svg key="frame3" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGradAg3" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#4ECDC4" />
              <stop offset="100%" stopColor="#44A08D" />
            </linearGradient>
            <linearGradient id="skinGradAg3" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
          </defs>
          {/* Cabeça */}
          <circle cx="200" cy="140" r="35" fill="url(#skinGradAg3)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="135" r="3" fill="#333"/>
          <circle cx="210" cy="135" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="175" x2="200" y2="195" stroke="url(#skinGradAg3)" strokeWidth="18"/>
          
          {/* Tronco muito inclinado */}
          <ellipse cx="200" cy="240" rx="70" ry="50" fill="url(#torsoGradAg3)"/>
          
          {/* Braços para frente */}
          <g>
            <path d="M 140 220 L 60 200" stroke="url(#skinGradAg3)" strokeWidth="18" strokeLinecap="round" fill="none"/>
            <circle cx="60" cy="200" r="10" fill="url(#skinGradAg3)" stroke="#E8B39E" strokeWidth="1"/>
            
            <path d="M 260 220 L 340 200" stroke="url(#skinGradAg3)" strokeWidth="18" strokeLinecap="round" fill="none"/>
            <circle cx="340" cy="200" r="10" fill="url(#skinGradAg3)" stroke="#E8B39E" strokeWidth="1"/>
          </g>
          
          {/* Coxas bem flexionadas */}
          <path d="M 185 290 Q 175 320 170 360" stroke="url(#skinGradAg3)" strokeWidth="25" strokeLinecap="round" fill="none"/>
          <path d="M 215 290 Q 225 320 230 360" stroke="url(#skinGradAg3)" strokeWidth="25" strokeLinecap="round" fill="none"/>
          
          {/* Panturrilhas */}
          <line x1="170" y1="360" x2="175" y2="410" stroke="#4A4A4A" strokeWidth="18" strokeLinecap="round"/>
          <line x1="230" y1="360" x2="225" y2="410" stroke="#4A4A4A" strokeWidth="18" strokeLinecap="round"/>
          
          {/* Pés */}
          <ellipse cx="175" cy="425" rx="18" ry="20" fill="#2a2a2a"/>
          <ellipse cx="225" cy="425" rx="18" ry="20" fill="#2a2a2a"/>
        </svg>,
      ]
    },
    'Rosca Direta Halteres': {
      frames: [
        // Posição inicial
        <svg key="frame1" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGradRosca1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFB627" />
              <stop offset="100%" stopColor="#FF9F1C" />
            </linearGradient>
            <linearGradient id="skinGradRosca1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
          </defs>
          {/* Pés */}
          <ellipse cx="185" cy="420" rx="20" ry="18" fill="#2a2a2a"/>
          <ellipse cx="215" cy="420" rx="20" ry="18" fill="#2a2a2a"/>
          
          {/* Panturrilhas */}
          <line x1="180" y1="360" x2="185" y2="420" stroke="#4A4A4A" strokeWidth="20" strokeLinecap="round"/>
          <line x1="220" y1="360" x2="215" y2="420" stroke="#4A4A4A" strokeWidth="20" strokeLinecap="round"/>
          
          {/* Coxas */}
          <line x1="185" y1="260" x2="180" y2="360" stroke="url(#skinGradRosca1)" strokeWidth="24" strokeLinecap="round"/>
          <line x1="215" y1="260" x2="220" y2="360" stroke="url(#skinGradRosca1)" strokeWidth="24" strokeLinecap="round"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="160" rx="80" ry="60" fill="url(#torsoGradRosca1)"/>
          
          {/* Cabeça */}
          <circle cx="200" cy="70" r="35" fill="url(#skinGradRosca1)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="65" r="3" fill="#333"/>
          <circle cx="210" cy="65" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="105" x2="200" y2="130" stroke="url(#skinGradRosca1)" strokeWidth="18"/>
          
          {/* Braço esquerdo - abaixado */}
          <g>
            <line x1="130" y1="140" x2="90" y2="280" stroke="url(#skinGradRosca1)" strokeWidth="22" strokeLinecap="round"/>
            <circle cx="90" cy="280" r="12" fill="url(#skinGradRosca1)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere esquerdo */}
            <rect x="70" y="275" width="40" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="67" cy="280" r="9" fill="#FF3B30"/>
            <circle cx="112" cy="280" r="9" fill="#FF3B30"/>
            <rect x="65" y="278" width="6" height="4" fill="#FFB627" opacity="0.6"/>
            <rect x="108" y="278" width="6" height="4" fill="#FFB627" opacity="0.6"/>
          </g>
          
          {/* Braço direito - abaixado */}
          <g>
            <line x1="270" y1="140" x2="310" y2="280" stroke="url(#skinGradRosca1)" strokeWidth="22" strokeLinecap="round"/>
            <circle cx="310" cy="280" r="12" fill="url(#skinGradRosca1)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere direito */}
            <rect x="290" y="275" width="40" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="288" cy="280" r="9" fill="#FF3B30"/>
            <circle cx="333" cy="280" r="9" fill="#FF3B30"/>
            <rect x="286" y="278" width="6" height="4" fill="#FFB627" opacity="0.6"/>
            <rect x="329" y="278" width="6" height="4" fill="#FFB627" opacity="0.6"/>
          </g>
        </svg>,
        
        // Posição intermediária
        <svg key="frame2" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGradRosca2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFB627" />
              <stop offset="100%" stopColor="#FF9F1C" />
            </linearGradient>
            <linearGradient id="skinGradRosca2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
          </defs>
          {/* Pés */}
          <ellipse cx="185" cy="420" rx="20" ry="18" fill="#2a2a2a"/>
          <ellipse cx="215" cy="420" rx="20" ry="18" fill="#2a2a2a"/>
          
          {/* Panturrilhas */}
          <line x1="180" y1="360" x2="185" y2="420" stroke="#4A4A4A" strokeWidth="20" strokeLinecap="round"/>
          <line x1="220" y1="360" x2="215" y2="420" stroke="#4A4A4A" strokeWidth="20" strokeLinecap="round"/>
          
          {/* Coxas */}
          <line x1="185" y1="260" x2="180" y2="360" stroke="url(#skinGradRosca2)" strokeWidth="24" strokeLinecap="round"/>
          <line x1="215" y1="260" x2="220" y2="360" stroke="url(#skinGradRosca2)" strokeWidth="24" strokeLinecap="round"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="160" rx="80" ry="60" fill="url(#torsoGradRosca2)"/>
          
          {/* Cabeça */}
          <circle cx="200" cy="70" r="35" fill="url(#skinGradRosca2)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="65" r="3" fill="#333"/>
          <circle cx="210" cy="65" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="105" x2="200" y2="130" stroke="url(#skinGradRosca2)" strokeWidth="18"/>
          
          {/* Braço esquerdo - flexionado */}
          <g>
            <path d="M 130 140 Q 100 180 95 220" stroke="url(#skinGradRosca2)" strokeWidth="22" strokeLinecap="round" fill="none"/>
            <circle cx="95" cy="220" r="12" fill="url(#skinGradRosca2)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere esquerdo */}
            <rect x="75" y="215" width="40" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="72" cy="220" r="9" fill="#FF3B30"/>
            <circle cx="117" cy="220" r="9" fill="#FF3B30"/>
            <rect x="70" y="218" width="6" height="4" fill="#FFB627" opacity="0.6"/>
            <rect x="113" y="218" width="6" height="4" fill="#FFB627" opacity="0.6"/>
          </g>
          
          {/* Braço direito - flexionado */}
          <g>
            <path d="M 270 140 Q 300 180 305 220" stroke="url(#skinGradRosca2)" strokeWidth="22" strokeLinecap="round" fill="none"/>
            <circle cx="305" cy="220" r="12" fill="url(#skinGradRosca2)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere direito */}
            <rect x="285" y="215" width="40" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="283" cy="220" r="9" fill="#FF3B30"/>
            <circle cx="328" cy="220" r="9" fill="#FF3B30"/>
            <rect x="281" y="218" width="6" height="4" fill="#FFB627" opacity="0.6"/>
            <rect x="324" y="218" width="6" height="4" fill="#FFB627" opacity="0.6"/>
          </g>
        </svg>,
        
        // Posição final - contraído
        <svg key="frame3" viewBox="0 0 400 500" className="w-full h-full">
          <defs>
            <linearGradient id="torsoGradRosca3" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFB627" />
              <stop offset="100%" stopColor="#FF9F1C" />
            </linearGradient>
            <linearGradient id="skinGradRosca3" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFD4A3" />
              <stop offset="100%" stopColor="#FFBA88" />
            </linearGradient>
            <linearGradient id="muscleGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FF6B9D" />
              <stop offset="100%" stopColor="#FF3860" />
            </linearGradient>
          </defs>
          {/* Pés */}
          <ellipse cx="185" cy="420" rx="20" ry="18" fill="#2a2a2a"/>
          <ellipse cx="215" cy="420" rx="20" ry="18" fill="#2a2a2a"/>
          
          {/* Panturrilhas */}
          <line x1="180" y1="360" x2="185" y2="420" stroke="#4A4A4A" strokeWidth="20" strokeLinecap="round"/>
          <line x1="220" y1="360" x2="215" y2="420" stroke="#4A4A4A" strokeWidth="20" strokeLinecap="round"/>
          
          {/* Coxas */}
          <line x1="185" y1="260" x2="180" y2="360" stroke="url(#skinGradRosca3)" strokeWidth="24" strokeLinecap="round"/>
          <line x1="215" y1="260" x2="220" y2="360" stroke="url(#skinGradRosca3)" strokeWidth="24" strokeLinecap="round"/>
          
          {/* Tronco */}
          <ellipse cx="200" cy="160" rx="80" ry="60" fill="url(#torsoGradRosca3)"/>
          
          {/* Cabeça */}
          <circle cx="200" cy="70" r="35" fill="url(#skinGradRosca3)" stroke="#E8B39E" strokeWidth="2"/>
          <circle cx="190" cy="65" r="3" fill="#333"/>
          <circle cx="210" cy="65" r="3" fill="#333"/>
          
          {/* Pescoço */}
          <line x1="200" y1="105" x2="200" y2="130" stroke="url(#skinGradRosca3)" strokeWidth="18"/>
          
          {/* Braço esquerdo - contraído - mostrar bíceps */}
          <g>
            <line x1="130" y1="140" x2="115" y2="180" stroke="url(#skinGradRosca3)" strokeWidth="26" strokeLinecap="round"/>
            {/* Bíceps pronunciado */}
            <ellipse cx="122" cy="160" rx="16" ry="22" fill="url(#muscleGrad)"/>
            <circle cx="115" cy="180" r="12" fill="url(#skinGradRosca3)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere esquerdo */}
            <rect x="95" y="175" width="40" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="92" cy="180" r="9" fill="#FF3B30"/>
            <circle cx="137" cy="180" r="9" fill="#FF3B30"/>
            <rect x="90" y="178" width="6" height="4" fill="#FFB627" opacity="0.6"/>
            <rect x="133" y="178" width="6" height="4" fill="#FFB627" opacity="0.6"/>
          </g>
          
          {/* Braço direito - contraído */}
          <g>
            <line x1="270" y1="140" x2="285" y2="180" stroke="url(#skinGradRosca3)" strokeWidth="26" strokeLinecap="round"/>
            {/* Bíceps pronunciado */}
            <ellipse cx="278" cy="160" rx="16" ry="22" fill="url(#muscleGrad)"/>
            <circle cx="285" cy="180" r="12" fill="url(#skinGradRosca3)" stroke="#E8B39E" strokeWidth="1"/>
            {/* Haltere direito */}
            <rect x="265" y="175" width="40" height="10" fill="#1a1a1a" rx="2"/>
            <circle cx="263" cy="180" r="9" fill="#FF3B30"/>
            <circle cx="308" cy="180" r="9" fill="#FF3B30"/>
            <rect x="261" y="178" width="6" height="4" fill="#FFB627" opacity="0.6"/>
            <rect x="304" y="178" width="6" height="4" fill="#FFB627" opacity="0.6"/>
          </g>
        </svg>,
      ]
    },
  }

  const frames = animationData[exerciseName]?.frames || []
  const [currentFrame, setCurrentFrame] = useState(0)

  const playAnimation = () => {
    if (frames.length === 0) return

    let frame = 0
    const interval = setInterval(() => {
      frame = (frame + 1) % frames.length
      setCurrentFrame(frame)
    }, 800)

    return () => clearInterval(interval)
  }

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying)
    if (!isPlaying) {
      playAnimation()
    }
  }

  const [hasStarted, setHasStarted] = useState(false)

  if (!hasStarted && isPlaying && frames.length > 0) {
    setHasStarted(true)
    const interval = setInterval(() => {
      setCurrentFrame(prev => (prev + 1) % frames.length)
    }, 800)
    return () => clearInterval(interval)
  }

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl overflow-hidden shadow-2xl max-w-2xl w-full">
        <div className="flex justify-between items-center p-4 border-b border-border">
          <h3 className="text-lg font-semibold text-foreground">{exerciseName}</h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            ✕
          </button>
        </div>
        <div className="bg-gradient-to-br from-background to-card p-8">
          <div className="bg-black/30 rounded-lg p-8 mb-6 min-h-80 flex items-center justify-center">
            {frames.length > 0 ? (
              <div className="w-full h-80">{frames[currentFrame]}</div>
            ) : (
              <p className="text-muted-foreground">Animação não disponível</p>
            )}
          </div>
          <div className="flex gap-4 items-center justify-center">
            <button
              onClick={togglePlayPause}
              className="px-6 py-2 bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg font-semibold transition-colors flex items-center gap-2"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              {isPlaying ? 'Pausar' : 'Reproduzir'}
            </button>
            <div className="text-sm text-muted-foreground">
              {frames.length > 0 && `Etapa ${currentFrame + 1} de ${frames.length}`}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
