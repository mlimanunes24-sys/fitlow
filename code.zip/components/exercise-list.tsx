'use client'

import { useState } from 'react'
import ExerciseCard from './exercise-card'

interface Exercise {
  id: number
  name: string
  series: number
  reps: string
  rest: string
  difficulty: string
}

interface ExerciseListProps {
  exercises: Exercise[]
}

export default function ExerciseList({ exercises }: ExerciseListProps) {
  const [completed, setCompleted] = useState<number[]>([])

  const toggleCompleted = (id: number) => {
    setCompleted(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    )
  }

  const completionPercentage = Math.round((completed.length / exercises.length) * 100)

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-2xl font-bold">Exercícios do Treino</h2>
          <span className="text-sm text-muted-foreground">{completionPercentage}% completo</span>
        </div>
        <div className="w-full bg-secondary rounded-full h-3 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-300"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
      </div>

      <div className="grid gap-4">
        {exercises.map((exercise) => (
          <ExerciseCard
            key={exercise.id}
            exercise={exercise}
            isCompleted={completed.includes(exercise.id)}
            onToggle={() => toggleCompleted(exercise.id)}
          />
        ))}
      </div>

      {completed.length === exercises.length && (
        <div className="mt-8 p-6 bg-primary/10 border border-primary rounded-lg text-center">
          <p className="text-lg font-semibold text-primary">
            🎉 Parabéns! Você completou todos os exercícios do dia!
          </p>
        </div>
      )}
    </div>
  )
}
