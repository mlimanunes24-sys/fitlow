'use client'

import { ChevronRight } from 'lucide-react'

interface MuscleCardProps {
  muscle: {
    id: string
    name: string
    color: string
    exercises: number
  }
}

export default function MuscleCard({ muscle }: MuscleCardProps) {
  return (
    <div className="group cursor-pointer">
      <div className={`bg-gradient-to-br ${muscle.color} rounded-2xl p-8 h-40 flex flex-col justify-between transform transition-transform duration-300 hover:scale-105 shadow-lg hover:shadow-2xl`}>
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">{muscle.name}</h2>
          <p className="text-white/80">{muscle.exercises} exercícios</p>
        </div>
        <div className="flex items-center gap-2 text-white opacity-0 group-hover:opacity-100 transform -translate-x-2 group-hover:translate-x-0 transition-all duration-300">
          <span className="text-sm font-semibold">Ver treino</span>
          <ChevronRight className="w-5 h-5" />
        </div>
      </div>
    </div>
  )
}
