'use client'

import { Dumbbell, Menu, X } from 'lucide-react'
import { useState } from 'react'

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary rounded-lg">
              <Dumbbell className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-primary">FitFlow</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="/" className="text-foreground hover:text-primary transition">Início</a>
            <a href="/#" className="text-muted-foreground hover:text-primary transition">Sobre</a>
            <a href="/#" className="text-muted-foreground hover:text-primary transition">Contato</a>
          </nav>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-secondary rounded-lg transition"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-2">
            <a href="/" className="px-4 py-2 hover:bg-secondary rounded-lg transition">Início</a>
            <a href="/#" className="px-4 py-2 hover:bg-secondary rounded-lg transition">Sobre</a>
            <a href="/#" className="px-4 py-2 hover:bg-secondary rounded-lg transition">Contato</a>
          </nav>
        )}
      </div>
    </header>
  )
}
